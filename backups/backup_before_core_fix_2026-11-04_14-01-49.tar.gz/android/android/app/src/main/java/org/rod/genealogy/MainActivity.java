package org.rod.genealogy;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
